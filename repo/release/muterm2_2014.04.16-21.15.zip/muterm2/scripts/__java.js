//java = {
//    File: Java.type("java.io.File"),
//}

//println(java.io.File);

