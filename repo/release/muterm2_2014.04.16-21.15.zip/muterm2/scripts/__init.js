var bytesIn = [];

function reset() {
	bytesIn = [];
}

